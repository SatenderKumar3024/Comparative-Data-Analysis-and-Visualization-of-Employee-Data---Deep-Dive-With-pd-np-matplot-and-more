Panda|Compare DataFrame
=======================

.. code:: ipython3

    import pandas as pd  # For data manipulation and analysis
    import numpy as np  # For numerical computations
    import matplotlib.pyplot as plt  # For creating static, animated, and interactive visualizations
    import seaborn as sns  # For statistical data visualization based on Matplotlib
    import scipy  # For scientific and technical computing (including optimization, integration, and statistics)

.. code:: ipython3

    import pandas as pd 
    import numpy as np
    # Creating realistic data for employees
    data = {
        'Employee ID': np.arange(1001, 1011),
        'Employee Name': ['Satender Kumar', 'data 1', 'Jane Smith', 'Robert Brown', 'Emily Davis', 'Michael Wilson', 'Sarah Taylor', 'David Lee', 'Laura Johnson', 'James White'],
        'Department': ['Data Analyst', 'IT', 'Finance', 'Marketing', 'Sales', 'Operations', 'R&D', 'Support', 'Admin', 'Legal'],
        'Age': [24, np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60)],
        'Location': ['London, Canada', 'Toronto', 'London', 'Sydney', 'San Francisco', 'Paris', 'Berlin', 'Tokyo', 'Dubai', 'Singapore'],
        'Salary': np.random.randint(50000, 150000, size=10),
        'Years with Company': np.random.randint(1, 15, size=10),
        'Position': ['Data Analyst', 'Developer', 'Analyst', 'Designer', 'Consultant', 'Engineer', 'Scientist', 'Support Agent', 'Admin Assistant', 'Lawyer'],
        'Performance Score': np.random.randint(1, 5, size=10),
        'Bonus': np.random.randint(1000, 10000, size=10),
        'Gender': ['Male', 'Male', 'Female', 'Male', 'Female', 'Male', 'Female', 'Male', 'Female', 'Male'],
        'Marital Status': ['Single', 'Single', 'Married', 'Single', 'Single', 'Married', 'Married', 'Single', 'Married', 'Single'],
        'Education': ['Bachelor', 'Master', 'PhD', 'Bachelor', 'Master', 'PhD', 'Bachelor', 'Master', 'Bachelor', 'Master'],
        'Hire Date': pd.to_datetime(['2019-06-12', '2015-07-23', '2012-09-05', '2018-11-30', '2013-05-19', '2019-02-14', '2020-08-21', '2016-06-03', '2014-01-28', '2017-03-15']),
        'Overtime Hours': np.random.randint(0, 20, size=10),
        'Sick Days Taken': np.random.randint(0, 10, size=10),
        'Vacation Days Taken': np.random.randint(5, 20, size=10),
        'Training Hours': np.random.randint(10, 50, size=10),
        'Certifications': ['Yes', 'No', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes', 'No', 'Yes'],
        'Supervisor': ['Anna Smith', 'Brian Adams', 'Clara Jones', 'Daniel Martin', 'Eva Rodriguez', 'Frank Bell', 'Grace Moore', 'Hannah Lewis', 'Ivan Scott', 'Jake Miller']
    }
    
    # Creating the DataFrame
    df = pd.DataFrame(data)

.. code:: ipython3

    df




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Employee ID</th>
          <th>Employee Name</th>
          <th>Department</th>
          <th>Age</th>
          <th>Location</th>
          <th>Salary</th>
          <th>Years with Company</th>
          <th>Position</th>
          <th>Performance Score</th>
          <th>Bonus</th>
          <th>Gender</th>
          <th>Marital Status</th>
          <th>Education</th>
          <th>Hire Date</th>
          <th>Overtime Hours</th>
          <th>Sick Days Taken</th>
          <th>Vacation Days Taken</th>
          <th>Training Hours</th>
          <th>Certifications</th>
          <th>Supervisor</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1001</td>
          <td>Satender Kumar</td>
          <td>Data Analyst</td>
          <td>24</td>
          <td>London, Canada</td>
          <td>113479</td>
          <td>3</td>
          <td>Data Analyst</td>
          <td>4</td>
          <td>9480</td>
          <td>Male</td>
          <td>Single</td>
          <td>Bachelor</td>
          <td>2019-06-12</td>
          <td>18</td>
          <td>9</td>
          <td>12</td>
          <td>19</td>
          <td>Yes</td>
          <td>Anna Smith</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1002</td>
          <td>data 1</td>
          <td>IT</td>
          <td>34</td>
          <td>Toronto</td>
          <td>127453</td>
          <td>9</td>
          <td>Developer</td>
          <td>4</td>
          <td>6577</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2015-07-23</td>
          <td>11</td>
          <td>2</td>
          <td>15</td>
          <td>31</td>
          <td>No</td>
          <td>Brian Adams</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1003</td>
          <td>Jane Smith</td>
          <td>Finance</td>
          <td>27</td>
          <td>London</td>
          <td>118316</td>
          <td>7</td>
          <td>Analyst</td>
          <td>1</td>
          <td>4972</td>
          <td>Female</td>
          <td>Married</td>
          <td>PhD</td>
          <td>2012-09-05</td>
          <td>6</td>
          <td>2</td>
          <td>10</td>
          <td>30</td>
          <td>Yes</td>
          <td>Clara Jones</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1004</td>
          <td>Robert Brown</td>
          <td>Marketing</td>
          <td>59</td>
          <td>Sydney</td>
          <td>109725</td>
          <td>10</td>
          <td>Designer</td>
          <td>3</td>
          <td>4624</td>
          <td>Male</td>
          <td>Single</td>
          <td>Bachelor</td>
          <td>2018-11-30</td>
          <td>17</td>
          <td>8</td>
          <td>14</td>
          <td>29</td>
          <td>No</td>
          <td>Daniel Martin</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1005</td>
          <td>Emily Davis</td>
          <td>Sales</td>
          <td>36</td>
          <td>San Francisco</td>
          <td>99006</td>
          <td>14</td>
          <td>Consultant</td>
          <td>3</td>
          <td>3218</td>
          <td>Female</td>
          <td>Single</td>
          <td>Master</td>
          <td>2013-05-19</td>
          <td>16</td>
          <td>9</td>
          <td>18</td>
          <td>14</td>
          <td>Yes</td>
          <td>Eva Rodriguez</td>
        </tr>
        <tr>
          <th>5</th>
          <td>1006</td>
          <td>Michael Wilson</td>
          <td>Operations</td>
          <td>36</td>
          <td>Paris</td>
          <td>123386</td>
          <td>8</td>
          <td>Engineer</td>
          <td>1</td>
          <td>4450</td>
          <td>Male</td>
          <td>Married</td>
          <td>PhD</td>
          <td>2019-02-14</td>
          <td>14</td>
          <td>3</td>
          <td>7</td>
          <td>14</td>
          <td>No</td>
          <td>Frank Bell</td>
        </tr>
        <tr>
          <th>6</th>
          <td>1007</td>
          <td>Sarah Taylor</td>
          <td>R&amp;D</td>
          <td>54</td>
          <td>Berlin</td>
          <td>77293</td>
          <td>13</td>
          <td>Scientist</td>
          <td>2</td>
          <td>2823</td>
          <td>Female</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2020-08-21</td>
          <td>4</td>
          <td>5</td>
          <td>6</td>
          <td>11</td>
          <td>Yes</td>
          <td>Grace Moore</td>
        </tr>
        <tr>
          <th>7</th>
          <td>1008</td>
          <td>David Lee</td>
          <td>Support</td>
          <td>32</td>
          <td>Tokyo</td>
          <td>65542</td>
          <td>9</td>
          <td>Support Agent</td>
          <td>2</td>
          <td>1486</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2016-06-03</td>
          <td>3</td>
          <td>4</td>
          <td>15</td>
          <td>21</td>
          <td>Yes</td>
          <td>Hannah Lewis</td>
        </tr>
        <tr>
          <th>8</th>
          <td>1009</td>
          <td>Laura Johnson</td>
          <td>Admin</td>
          <td>50</td>
          <td>Dubai</td>
          <td>87223</td>
          <td>9</td>
          <td>Admin Assistant</td>
          <td>2</td>
          <td>1705</td>
          <td>Female</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2014-01-28</td>
          <td>13</td>
          <td>8</td>
          <td>15</td>
          <td>44</td>
          <td>No</td>
          <td>Ivan Scott</td>
        </tr>
        <tr>
          <th>9</th>
          <td>1010</td>
          <td>James White</td>
          <td>Legal</td>
          <td>25</td>
          <td>Singapore</td>
          <td>110051</td>
          <td>5</td>
          <td>Lawyer</td>
          <td>2</td>
          <td>8724</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2017-03-15</td>
          <td>6</td>
          <td>6</td>
          <td>6</td>
          <td>45</td>
          <td>Yes</td>
          <td>Jake Miller</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    # Creating realistic data for a second set of employees
    data1 = {
        'Employee ID': np.arange(1011, 1021),
        'Employee Name': ['Satender Kumar', 'data 1', 'Chris Evans', 'Natalie Portman', 'Tom Holland', 'Emma Watson', 'Daniel Radcliffe', 'Scarlett Johansson', 'Robert Downey Jr.', 'Mark Ruffalo'],
        'Department': ['Data Analyst', 'HR', 'IT', 'Marketing', 'Finance', 'Sales', 'R&D', 'Operations', 'Legal', 'Support'],
        'Age': [24, np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60), np.random.randint(25, 60)],
        'Location': ['London, Canada', 'Los Angeles', 'New York', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia', 'San Antonio', 'San Diego', 'Dallas'],
        'Salary': np.random.randint(60000, 160000, size=10),
        'Years with Company': np.random.randint(1, 20, size=10),
        'Position': ['Data Analyst', 'HR Manager', 'IT Specialist', 'Marketing Coordinator', 'Financial Analyst', 'Sales Manager', 'Research Scientist', 'Operations Manager', 'Legal Advisor', 'Support Specialist'],
        'Performance Score': np.random.randint(1, 5, size=10),
        'Bonus': np.random.randint(2000, 12000, size=10),
        'Gender': ['Male', 'Male', 'Female', 'Female', 'Male', 'Female', 'Male', 'Female', 'Male', 'Male'],
        'Marital Status': ['Single', 'Married', 'Single', 'Single', 'Married', 'Single', 'Single', 'Married', 'Single', 'Married'],
        'Education': ['Master', 'Bachelor', 'Master', 'PhD', 'Bachelor', 'Master', 'PhD', 'Bachelor', 'Master', 'PhD'],
        'Hire Date': pd.to_datetime(['2018-07-15', '2014-03-22', '2011-10-12', '2017-04-17', '2015-09-23', '2016-11-01', '2019-05-11', '2020-07-08', '2013-08-19', '2012-01-09']),
        'Overtime Hours': np.random.randint(0, 25, size=10),
        'Sick Days Taken': np.random.randint(0, 8, size=10),
        'Vacation Days Taken': np.random.randint(7, 22, size=10),
        'Training Hours': np.random.randint(15, 55, size=10),
        'Certifications': ['Yes', 'Yes', 'No', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes', 'No'],
        'Supervisor': ['John Smith', 'Michael Johnson', 'Patricia Williams', 'Linda Brown', 'Barbara Jones', 'Elizabeth Garcia', 'Susan Martinez', 'Jessica Hernandez', 'Sarah Lopez', 'Karen Wilson']
    }
    
    # Creating the second DataFrame
    df1 = pd.DataFrame(data1)

.. code:: ipython3

    df1




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Employee ID</th>
          <th>Employee Name</th>
          <th>Department</th>
          <th>Age</th>
          <th>Location</th>
          <th>Salary</th>
          <th>Years with Company</th>
          <th>Position</th>
          <th>Performance Score</th>
          <th>Bonus</th>
          <th>Gender</th>
          <th>Marital Status</th>
          <th>Education</th>
          <th>Hire Date</th>
          <th>Overtime Hours</th>
          <th>Sick Days Taken</th>
          <th>Vacation Days Taken</th>
          <th>Training Hours</th>
          <th>Certifications</th>
          <th>Supervisor</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1011</td>
          <td>Satender Kumar</td>
          <td>Data Analyst</td>
          <td>24</td>
          <td>London, Canada</td>
          <td>125763</td>
          <td>9</td>
          <td>Data Analyst</td>
          <td>4</td>
          <td>9043</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2018-07-15</td>
          <td>22</td>
          <td>7</td>
          <td>15</td>
          <td>53</td>
          <td>Yes</td>
          <td>John Smith</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1012</td>
          <td>data 1</td>
          <td>HR</td>
          <td>29</td>
          <td>Los Angeles</td>
          <td>149163</td>
          <td>18</td>
          <td>HR Manager</td>
          <td>4</td>
          <td>5174</td>
          <td>Male</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2014-03-22</td>
          <td>20</td>
          <td>5</td>
          <td>19</td>
          <td>17</td>
          <td>Yes</td>
          <td>Michael Johnson</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1013</td>
          <td>Chris Evans</td>
          <td>IT</td>
          <td>58</td>
          <td>New York</td>
          <td>149334</td>
          <td>15</td>
          <td>IT Specialist</td>
          <td>4</td>
          <td>4389</td>
          <td>Female</td>
          <td>Single</td>
          <td>Master</td>
          <td>2011-10-12</td>
          <td>22</td>
          <td>6</td>
          <td>13</td>
          <td>45</td>
          <td>No</td>
          <td>Patricia Williams</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1014</td>
          <td>Natalie Portman</td>
          <td>Marketing</td>
          <td>41</td>
          <td>Chicago</td>
          <td>152579</td>
          <td>13</td>
          <td>Marketing Coordinator</td>
          <td>4</td>
          <td>3100</td>
          <td>Female</td>
          <td>Single</td>
          <td>PhD</td>
          <td>2017-04-17</td>
          <td>7</td>
          <td>4</td>
          <td>20</td>
          <td>34</td>
          <td>Yes</td>
          <td>Linda Brown</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1015</td>
          <td>Tom Holland</td>
          <td>Finance</td>
          <td>55</td>
          <td>Houston</td>
          <td>87396</td>
          <td>11</td>
          <td>Financial Analyst</td>
          <td>1</td>
          <td>5710</td>
          <td>Male</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2015-09-23</td>
          <td>10</td>
          <td>1</td>
          <td>18</td>
          <td>17</td>
          <td>No</td>
          <td>Barbara Jones</td>
        </tr>
        <tr>
          <th>5</th>
          <td>1016</td>
          <td>Emma Watson</td>
          <td>Sales</td>
          <td>34</td>
          <td>Phoenix</td>
          <td>132586</td>
          <td>8</td>
          <td>Sales Manager</td>
          <td>1</td>
          <td>2777</td>
          <td>Female</td>
          <td>Single</td>
          <td>Master</td>
          <td>2016-11-01</td>
          <td>11</td>
          <td>7</td>
          <td>14</td>
          <td>48</td>
          <td>Yes</td>
          <td>Elizabeth Garcia</td>
        </tr>
        <tr>
          <th>6</th>
          <td>1017</td>
          <td>Daniel Radcliffe</td>
          <td>R&amp;D</td>
          <td>56</td>
          <td>Philadelphia</td>
          <td>143832</td>
          <td>10</td>
          <td>Research Scientist</td>
          <td>2</td>
          <td>6264</td>
          <td>Male</td>
          <td>Single</td>
          <td>PhD</td>
          <td>2019-05-11</td>
          <td>8</td>
          <td>4</td>
          <td>8</td>
          <td>46</td>
          <td>No</td>
          <td>Susan Martinez</td>
        </tr>
        <tr>
          <th>7</th>
          <td>1018</td>
          <td>Scarlett Johansson</td>
          <td>Operations</td>
          <td>35</td>
          <td>San Antonio</td>
          <td>61204</td>
          <td>1</td>
          <td>Operations Manager</td>
          <td>4</td>
          <td>9008</td>
          <td>Female</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2020-07-08</td>
          <td>8</td>
          <td>0</td>
          <td>16</td>
          <td>54</td>
          <td>Yes</td>
          <td>Jessica Hernandez</td>
        </tr>
        <tr>
          <th>8</th>
          <td>1019</td>
          <td>Robert Downey Jr.</td>
          <td>Legal</td>
          <td>26</td>
          <td>San Diego</td>
          <td>69724</td>
          <td>17</td>
          <td>Legal Advisor</td>
          <td>4</td>
          <td>7002</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2013-08-19</td>
          <td>12</td>
          <td>4</td>
          <td>7</td>
          <td>18</td>
          <td>Yes</td>
          <td>Sarah Lopez</td>
        </tr>
        <tr>
          <th>9</th>
          <td>1020</td>
          <td>Mark Ruffalo</td>
          <td>Support</td>
          <td>33</td>
          <td>Dallas</td>
          <td>134630</td>
          <td>11</td>
          <td>Support Specialist</td>
          <td>1</td>
          <td>2651</td>
          <td>Male</td>
          <td>Married</td>
          <td>PhD</td>
          <td>2012-01-09</td>
          <td>20</td>
          <td>6</td>
          <td>21</td>
          <td>31</td>
          <td>No</td>
          <td>Karen Wilson</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Employee ID</th>
          <th>Employee Name</th>
          <th>Department</th>
          <th>Age</th>
          <th>Location</th>
          <th>Salary</th>
          <th>Years with Company</th>
          <th>Position</th>
          <th>Performance Score</th>
          <th>Bonus</th>
          <th>Gender</th>
          <th>Marital Status</th>
          <th>Education</th>
          <th>Hire Date</th>
          <th>Overtime Hours</th>
          <th>Sick Days Taken</th>
          <th>Vacation Days Taken</th>
          <th>Training Hours</th>
          <th>Certifications</th>
          <th>Supervisor</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1001</td>
          <td>Satender Kumar</td>
          <td>Data Analyst</td>
          <td>24</td>
          <td>London, Canada</td>
          <td>113479</td>
          <td>3</td>
          <td>Data Analyst</td>
          <td>4</td>
          <td>9480</td>
          <td>Male</td>
          <td>Single</td>
          <td>Bachelor</td>
          <td>2019-06-12</td>
          <td>18</td>
          <td>9</td>
          <td>12</td>
          <td>19</td>
          <td>Yes</td>
          <td>Anna Smith</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1002</td>
          <td>data 1</td>
          <td>IT</td>
          <td>34</td>
          <td>Toronto</td>
          <td>127453</td>
          <td>9</td>
          <td>Developer</td>
          <td>4</td>
          <td>6577</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2015-07-23</td>
          <td>11</td>
          <td>2</td>
          <td>15</td>
          <td>31</td>
          <td>No</td>
          <td>Brian Adams</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1003</td>
          <td>Jane Smith</td>
          <td>Finance</td>
          <td>27</td>
          <td>London</td>
          <td>118316</td>
          <td>7</td>
          <td>Analyst</td>
          <td>1</td>
          <td>4972</td>
          <td>Female</td>
          <td>Married</td>
          <td>PhD</td>
          <td>2012-09-05</td>
          <td>6</td>
          <td>2</td>
          <td>10</td>
          <td>30</td>
          <td>Yes</td>
          <td>Clara Jones</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1004</td>
          <td>Robert Brown</td>
          <td>Marketing</td>
          <td>59</td>
          <td>Sydney</td>
          <td>109725</td>
          <td>10</td>
          <td>Designer</td>
          <td>3</td>
          <td>4624</td>
          <td>Male</td>
          <td>Single</td>
          <td>Bachelor</td>
          <td>2018-11-30</td>
          <td>17</td>
          <td>8</td>
          <td>14</td>
          <td>29</td>
          <td>No</td>
          <td>Daniel Martin</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1005</td>
          <td>Emily Davis</td>
          <td>Sales</td>
          <td>36</td>
          <td>San Francisco</td>
          <td>99006</td>
          <td>14</td>
          <td>Consultant</td>
          <td>3</td>
          <td>3218</td>
          <td>Female</td>
          <td>Single</td>
          <td>Master</td>
          <td>2013-05-19</td>
          <td>16</td>
          <td>9</td>
          <td>18</td>
          <td>14</td>
          <td>Yes</td>
          <td>Eva Rodriguez</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    df1.head()




.. raw:: html

    <div>
    <style scoped>
        .dataframe tbody tr th:only-of-type {
            vertical-align: middle;
        }
    
        .dataframe tbody tr th {
            vertical-align: top;
        }
    
        .dataframe thead th {
            text-align: right;
        }
    </style>
    <table border="1" class="dataframe">
      <thead>
        <tr style="text-align: right;">
          <th></th>
          <th>Employee ID</th>
          <th>Employee Name</th>
          <th>Department</th>
          <th>Age</th>
          <th>Location</th>
          <th>Salary</th>
          <th>Years with Company</th>
          <th>Position</th>
          <th>Performance Score</th>
          <th>Bonus</th>
          <th>Gender</th>
          <th>Marital Status</th>
          <th>Education</th>
          <th>Hire Date</th>
          <th>Overtime Hours</th>
          <th>Sick Days Taken</th>
          <th>Vacation Days Taken</th>
          <th>Training Hours</th>
          <th>Certifications</th>
          <th>Supervisor</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <th>0</th>
          <td>1011</td>
          <td>Satender Kumar</td>
          <td>Data Analyst</td>
          <td>24</td>
          <td>London, Canada</td>
          <td>125763</td>
          <td>9</td>
          <td>Data Analyst</td>
          <td>4</td>
          <td>9043</td>
          <td>Male</td>
          <td>Single</td>
          <td>Master</td>
          <td>2018-07-15</td>
          <td>22</td>
          <td>7</td>
          <td>15</td>
          <td>53</td>
          <td>Yes</td>
          <td>John Smith</td>
        </tr>
        <tr>
          <th>1</th>
          <td>1012</td>
          <td>data 1</td>
          <td>HR</td>
          <td>29</td>
          <td>Los Angeles</td>
          <td>149163</td>
          <td>18</td>
          <td>HR Manager</td>
          <td>4</td>
          <td>5174</td>
          <td>Male</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2014-03-22</td>
          <td>20</td>
          <td>5</td>
          <td>19</td>
          <td>17</td>
          <td>Yes</td>
          <td>Michael Johnson</td>
        </tr>
        <tr>
          <th>2</th>
          <td>1013</td>
          <td>Chris Evans</td>
          <td>IT</td>
          <td>58</td>
          <td>New York</td>
          <td>149334</td>
          <td>15</td>
          <td>IT Specialist</td>
          <td>4</td>
          <td>4389</td>
          <td>Female</td>
          <td>Single</td>
          <td>Master</td>
          <td>2011-10-12</td>
          <td>22</td>
          <td>6</td>
          <td>13</td>
          <td>45</td>
          <td>No</td>
          <td>Patricia Williams</td>
        </tr>
        <tr>
          <th>3</th>
          <td>1014</td>
          <td>Natalie Portman</td>
          <td>Marketing</td>
          <td>41</td>
          <td>Chicago</td>
          <td>152579</td>
          <td>13</td>
          <td>Marketing Coordinator</td>
          <td>4</td>
          <td>3100</td>
          <td>Female</td>
          <td>Single</td>
          <td>PhD</td>
          <td>2017-04-17</td>
          <td>7</td>
          <td>4</td>
          <td>20</td>
          <td>34</td>
          <td>Yes</td>
          <td>Linda Brown</td>
        </tr>
        <tr>
          <th>4</th>
          <td>1015</td>
          <td>Tom Holland</td>
          <td>Finance</td>
          <td>55</td>
          <td>Houston</td>
          <td>87396</td>
          <td>11</td>
          <td>Financial Analyst</td>
          <td>1</td>
          <td>5710</td>
          <td>Male</td>
          <td>Married</td>
          <td>Bachelor</td>
          <td>2015-09-23</td>
          <td>10</td>
          <td>1</td>
          <td>18</td>
          <td>17</td>
          <td>No</td>
          <td>Barbara Jones</td>
        </tr>
      </tbody>
    </table>
    </div>



.. code:: ipython3

    # Check if df and df1 are exactly the same
    are_identical = df.equals(df1)
    print(f"Are df and df1 identical? {are_identical}")
    


.. parsed-literal::

    Are df and df1 identical? False
    

.. code:: ipython3

    # Find differences between df and df1
    comparison_df = df.compare(df1, keep_shape=True, keep_equal=True)
    print("Differences between df and df1:")
    print(comparison_df)
    


.. parsed-literal::

    Differences between df and df1:
      Employee ID         Employee Name                        Department  \
             self other            self               other          self   
    0        1001  1011  Satender Kumar      Satender Kumar  Data Analyst   
    1        1002  1012          data 1              data 1            IT   
    2        1003  1013      Jane Smith         Chris Evans       Finance   
    3        1004  1014    Robert Brown     Natalie Portman     Marketing   
    4        1005  1015     Emily Davis         Tom Holland         Sales   
    5        1006  1016  Michael Wilson         Emma Watson    Operations   
    6        1007  1017    Sarah Taylor    Daniel Radcliffe           R&D   
    7        1008  1018       David Lee  Scarlett Johansson       Support   
    8        1009  1019   Laura Johnson   Robert Downey Jr.         Admin   
    9        1010  1020     James White        Mark Ruffalo         Legal   
    
                     Age              Location                  ...  \
              other self other            self           other  ...   
    0  Data Analyst   24    24  London, Canada  London, Canada  ...   
    1            HR   34    29         Toronto     Los Angeles  ...   
    2            IT   27    58          London        New York  ...   
    3     Marketing   59    41          Sydney         Chicago  ...   
    4       Finance   36    55   San Francisco         Houston  ...   
    5         Sales   36    34           Paris         Phoenix  ...   
    6           R&D   54    56          Berlin    Philadelphia  ...   
    7    Operations   32    35           Tokyo     San Antonio  ...   
    8         Legal   50    26           Dubai       San Diego  ...   
    9       Support   25    33       Singapore          Dallas  ...   
    
      Sick Days Taken       Vacation Days Taken       Training Hours        \
                 self other                self other           self other   
    0               9     7                  12    15             19    53   
    1               2     5                  15    19             31    17   
    2               2     6                  10    13             30    45   
    3               8     4                  14    20             29    34   
    4               9     1                  18    18             14    17   
    5               3     7                   7    14             14    48   
    6               5     4                   6     8             11    46   
    7               4     0                  15    16             21    54   
    8               8     4                  15     7             44    18   
    9               6     6                   6    21             45    31   
    
      Certifications           Supervisor                     
                self other           self              other  
    0            Yes   Yes     Anna Smith         John Smith  
    1             No   Yes    Brian Adams    Michael Johnson  
    2            Yes    No    Clara Jones  Patricia Williams  
    3             No   Yes  Daniel Martin        Linda Brown  
    4            Yes    No  Eva Rodriguez      Barbara Jones  
    5             No   Yes     Frank Bell   Elizabeth Garcia  
    6            Yes    No    Grace Moore     Susan Martinez  
    7            Yes   Yes   Hannah Lewis  Jessica Hernandez  
    8             No   Yes     Ivan Scott        Sarah Lopez  
    9            Yes    No    Jake Miller       Karen Wilson  
    
    [10 rows x 40 columns]
    

.. code:: ipython3

    # Identify rows that differ between df and df1
    differing_rows = df[df.ne(df1).any(axis=1)]
    print("Rows that differ between df and df1:")
    print(differing_rows)
    


.. parsed-literal::

    Rows that differ between df and df1:
       Employee ID   Employee Name    Department  Age        Location  Salary  \
    0         1001  Satender Kumar  Data Analyst   24  London, Canada  113479   
    1         1002          data 1            IT   34         Toronto  127453   
    2         1003      Jane Smith       Finance   27          London  118316   
    3         1004    Robert Brown     Marketing   59          Sydney  109725   
    4         1005     Emily Davis         Sales   36   San Francisco   99006   
    5         1006  Michael Wilson    Operations   36           Paris  123386   
    6         1007    Sarah Taylor           R&D   54          Berlin   77293   
    7         1008       David Lee       Support   32           Tokyo   65542   
    8         1009   Laura Johnson         Admin   50           Dubai   87223   
    9         1010     James White         Legal   25       Singapore  110051   
    
       Years with Company         Position  Performance Score  Bonus  Gender  \
    0                   3     Data Analyst                  4   9480    Male   
    1                   9        Developer                  4   6577    Male   
    2                   7          Analyst                  1   4972  Female   
    3                  10         Designer                  3   4624    Male   
    4                  14       Consultant                  3   3218  Female   
    5                   8         Engineer                  1   4450    Male   
    6                  13        Scientist                  2   2823  Female   
    7                   9    Support Agent                  2   1486    Male   
    8                   9  Admin Assistant                  2   1705  Female   
    9                   5           Lawyer                  2   8724    Male   
    
      Marital Status Education  Hire Date  Overtime Hours  Sick Days Taken  \
    0         Single  Bachelor 2019-06-12              18                9   
    1         Single    Master 2015-07-23              11                2   
    2        Married       PhD 2012-09-05               6                2   
    3         Single  Bachelor 2018-11-30              17                8   
    4         Single    Master 2013-05-19              16                9   
    5        Married       PhD 2019-02-14              14                3   
    6        Married  Bachelor 2020-08-21               4                5   
    7         Single    Master 2016-06-03               3                4   
    8        Married  Bachelor 2014-01-28              13                8   
    9         Single    Master 2017-03-15               6                6   
    
       Vacation Days Taken  Training Hours Certifications     Supervisor  
    0                   12              19            Yes     Anna Smith  
    1                   15              31             No    Brian Adams  
    2                   10              30            Yes    Clara Jones  
    3                   14              29             No  Daniel Martin  
    4                   18              14            Yes  Eva Rodriguez  
    5                    7              14             No     Frank Bell  
    6                    6              11            Yes    Grace Moore  
    7                   15              21            Yes   Hannah Lewis  
    8                   15              44             No     Ivan Scott  
    9                    6              45            Yes    Jake Miller  
    

.. code:: ipython3

    import seaborn as sns
    import matplotlib.pyplot as plt
    
    # Create a heatmap to visualize differences between df and df1
    diff = df.ne(df1).astype(int)  # 1 where different, 0 where the same
    plt.figure(figsize=(12, 8))
    sns.heatmap(diff, cmap='coolwarm', cbar=False, annot=True)
    plt.title('Heatmap of Differences Between df and df1')
    plt.show()
    



.. image:: output_11_0.png


.. code:: ipython3

    # Summarize the number of differences by column
    summary = df.ne(df1).sum()
    print("Summary of differences by column:")
    print(summary)
    


.. parsed-literal::

    Summary of differences by column:
    Employee ID            10
    Employee Name           8
    Department              7
    Age                     9
    Location                9
    Salary                 10
    Years with Company      9
    Position                9
    Performance Score       6
    Bonus                  10
    Gender                  6
    Marital Status          8
    Education              10
    Hire Date              10
    Overtime Hours         10
    Sick Days Taken         9
    Vacation Days Taken     9
    Training Hours         10
    Certifications          8
    Supervisor             10
    dtype: int64
    

.. code:: ipython3

    import matplotlib.pyplot as plt
    
    # Overlayed histograms for 'Salary' in df and df1
    plt.figure(figsize=(10, 6))
    plt.hist(df['Salary'], bins=15, alpha=0.5, label='df Salary', color='blue')
    plt.hist(df1['Salary'], bins=15, alpha=0.5, label='df1 Salary', color='orange')
    plt.title('Overlayed Histograms of Salary in df and df1')
    plt.xlabel('Salary')
    plt.ylabel('Frequency')
    plt.legend()
    plt.show()
    



.. image:: output_13_0.png


.. code:: ipython3

    # Combine the data into a single DataFrame for side-by-side boxplots
    combined = pd.DataFrame({
        'df_Salary': df['Salary'],
        'df1_Salary': df1['Salary']
    })
    
    # Plot the boxplots
    plt.figure(figsize=(10, 6))
    combined.boxplot()
    plt.title('Side-by-Side Boxplots of Salary in df and df1')
    plt.ylabel('Salary')
    plt.show()
    



.. image:: output_14_0.png


.. code:: ipython3

    # Group by Department and count in both DataFrames
    df_dept_counts = df['Department'].value_counts()
    df1_dept_counts = df1['Department'].value_counts()
    
    # Combine into a single DataFrame
    dept_comparison = pd.DataFrame({'df': df_dept_counts, 'df1': df1_dept_counts})
    
    # Plot stacked bar plot
    dept_comparison.plot(kind='bar', stacked=True, figsize=(10, 6))
    plt.title('Stacked Bar Plot Comparing Department Distribution in df and df1')
    plt.ylabel('Number of Employees')
    plt.show()
    



.. image:: output_15_0.png


.. code:: ipython3

    # Scatter plot comparison for 'Age' vs 'Salary' in both DataFrames
    plt.figure(figsize=(12, 6))
    
    plt.subplot(1, 2, 1)
    plt.scatter(df['Age'], df['Salary'], color='blue', alpha=0.5)
    plt.title('df: Age vs Salary')
    plt.xlabel('Age')
    plt.ylabel('Salary')
    
    plt.subplot(1, 2, 2)
    plt.scatter(df1['Age'], df1['Salary'], color='orange', alpha=0.5)
    plt.title('df1: Age vs Salary')
    plt.xlabel('Age')
    plt.ylabel('Salary')
    
    plt.show()
    



.. image:: output_16_0.png


.. code:: ipython3

    # Density plot for 'Years with Company' in df and df1
    plt.figure(figsize=(10, 6))
    df['Years with Company'].plot(kind='density', label='df Years with Company', color='blue')
    df1['Years with Company'].plot(kind='density', label='df1 Years with Company', color='orange')
    plt.title('Density Plot of Years with Company in df and df1')
    plt.xlabel('Years with Company')
    plt.legend()
    plt.show()
    



.. image:: output_17_0.png


.. code:: ipython3

    # Group by Gender and count in both DataFrames
    df_gender_counts = df['Gender'].value_counts()
    df1_gender_counts = df1['Gender'].value_counts()
    
    # Combine into a single DataFrame
    gender_comparison = pd.DataFrame({'df': df_gender_counts, 'df1': df1_gender_counts})
    
    # Plot clustered bar plot
    gender_comparison.plot(kind='bar', width=0.8, figsize=(10, 6))
    plt.title('Clustered Bar Plot Comparing Gender Distribution in df and df1')
    plt.ylabel('Number of Employees')
    plt.show()
    



.. image:: output_18_0.png


.. code:: ipython3

    # Group by Gender and count in both DataFrames
    df_gender_counts = df['Gender'].value_counts()
    df1_gender_counts = df1['Gender'].value_counts()
    
    # Combine into a single DataFrame
    gender_comparison = pd.DataFrame({'df': df_gender_counts, 'df1': df1_gender_counts})
    
    # Plot clustered bar plot
    gender_comparison.plot(kind='bar', width=0.8, figsize=(10, 6))
    plt.title('Clustered Bar Plot Comparing Gender Distribution in df and df1')
    plt.ylabel('Number of Employees')
    plt.show()
    



.. image:: output_19_0.png


.. code:: ipython3

    # Bubble plot for Age vs Salary with Performance Score as bubble size
    plt.figure(figsize=(10, 6))
    
    plt.scatter(df['Age'], df['Salary'], s=df['Performance Score']*100, alpha=0.5, label='df', color='blue')
    plt.scatter(df1['Age'], df1['Salary'], s=df1['Performance Score']*100, alpha=0.5, label='df1', color='orange')
    
    plt.title('Bubble Plot Comparing Age vs Salary in df and df1')
    plt.xlabel('Age')
    plt.ylabel('Salary')
    plt.legend()
    plt.show()
    



.. image:: output_20_0.png


.. code:: ipython3

    # Comparing first employee in both DataFrames using a radar chart
    categories = ['Age', 'Salary', 'Years with Company', 'Performance Score', 'Bonus']
    df_values = df.loc[0, categories].values.flatten().tolist()
    df1_values = df1.loc[0, categories].values.flatten().tolist()
    
    # Closing the radar chart by adding the first value at the end
    df_values += df_values[:1]
    df1_values += df1_values[:1]
    angles = np.linspace(0, 2 * np.pi, len(categories), endpoint=False).tolist()
    angles += angles[:1]
    
    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    ax.fill(angles, df_values, color='blue', alpha=0.25, label='df')
    ax.plot(angles, df_values, color='blue', linewidth=2)
    
    ax.fill(angles, df1_values, color='orange', alpha=0.25, label='df1')
    ax.plot(angles, df1_values, color='orange', linewidth=2)
    
    ax.set_yticklabels([])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories)
    plt.title('Radar Chart Comparing First Employee in df and df1')
    plt.legend()
    plt.show()
    



.. image:: output_21_0.png

